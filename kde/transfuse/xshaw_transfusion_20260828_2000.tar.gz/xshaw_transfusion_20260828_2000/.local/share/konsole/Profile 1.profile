[Appearance]
ColorScheme=GreenOnBlack
Font=Hack,18,-1,5,400,0,0,0,0,0,0,0,0,0,0,1,,0,0

[Cursor Options]
CursorShape=0

[General]
Name=Profile 1
Parent=FALLBACK/
TerminalColumns=150
